class StackADT:
    """Stack ADT implementation using Python list."""
    
    def __init__(self):
        self._items = []
    
    def push(self, item):
        self._items.append(item)
    
    def pop(self):
        if not self.is_empty():
            return self._items.pop()
        return None
    
    def peek(self):
        if not self.is_empty():
            return self._items[-1]
        return None
    
    def is_empty(self):
        return len(self._items) == 0
    
    def size(self):
        return len(self._items)
    
    def __str__(self):
        return str(self._items)

call_count = 0

def reset_counter():
    global call_count
    call_count = 0


def factorial(n):
    if n < 0:
        raise ValueError("Factorial not defined for negative numbers")
    if n == 0:  # Base case
        return 1
    return n * factorial(n - 1)


def fib_naive(n):
    global call_count
    call_count += 1
    
    if n <= 0:
        return 0
    if n == 1:
        return 1
    return fib_naive(n - 1) + fib_naive(n - 2)

memo_cache = {}

def fib_memo(n):
    global call_count
    call_count += 1
    
    if n <= 0:
        return 0
    if n == 1:
        return 1
    if n in memo_cache:
        return memo_cache[n]
    
    memo_cache[n] = fib_memo(n - 1) + fib_memo(n - 2)
    return memo_cache[n]


def hanoi(n, source, auxiliary, destination, moves_stack=None):
    if n == 1:
        move = f"Move disk 1 from {source} to {destination}"
        print(move)
        if moves_stack:
            moves_stack.push(move)
        return
    
    hanoi(n - 1, source, destination, auxiliary, moves_stack)
    
    move = f"Move disk {n} from {source} to {destination}"
    print(move)
    if moves_stack:
        moves_stack.push(move)
    
    hanoi(n - 1, auxiliary, source, destination, moves_stack)


def binary_search(arr, key, low, high, mid_stack=None):

    if low > high:
        return -1
    
    mid = (low + high) // 2
    
    if mid_stack:
        mid_stack.push(mid)
    
    if arr[mid] == key:
        return mid
    elif key < arr[mid]:
        return binary_search(arr, key, low, mid - 1, mid_stack)
    else:
        return binary_search(arr, key, mid + 1, high, mid_stack)


def test_factorial():
    print("\n" + "="*50)
    print("TESTING FACTORIAL")
    print("="*50)
    
    test_cases = [0, 1, 5, 10]
    for n in test_cases:
        result = factorial(n)
        print(f"factorial({n}) = {result}")


def test_fibonacci():
    """Test both Fibonacci versions with call counting."""
    print("\n" + "="*50)
    print("TESTING FIBONACCI")
    print("="*50)
    
    test_cases = [5, 10, 20, 30]
    
    for n in test_cases:
        print(f"\n--- n = {n} ---")
        
        # Naive Fibonacci
        global call_count
        reset_counter()
        memo_cache.clear()
        
        result_naive = fib_naive(n)
        naive_calls = call_count
        
        # Memoized Fibonacci
        reset_counter()
        result_memo = fib_memo(n)
        memo_calls = call_count
        
        print(f"Naive Fibonacci: {result_naive}, Calls: {naive_calls}")
        print(f"Memoized Fibonacci: {result_memo}, Calls: {memo_calls}")


def test_hanoi():
    """Test Tower of Hanoi for N=3."""
    print("\n" + "="*50)
    print("TESTING TOWER OF HANOI (N=3)")
    print("="*50)
    
    moves_stack = StackADT()
    hanoi(3, 'A', 'B', 'C', moves_stack)
    
    print(f"\nMoves recorded in stack (size: {moves_stack.size()}):")
    print("Stack contents (top to bottom):")
    temp_stack = StackADT()
    
    while not moves_stack.is_empty():
        move = moves_stack.pop()
        temp_stack.push(move)
    
    move_num = 1
    while not temp_stack.is_empty():
        print(f"  Move {move_num}: {temp_stack.pop()}")
        move_num += 1


def test_binary_search():
    """Test recursive binary search."""
    print("\n" + "="*50)
    print("TESTING BINARY SEARCH")
    print("="*50)
    
    # Test case 1: Normal array
    arr = [1, 3, 5, 7, 9, 11, 13]
    print(f"\nArray: {arr}")
    
    test_keys = [7, 1, 13, 2]
    
    for key in test_keys:
        mid_stack = StackADT()
        result = binary_search(arr, key, 0, len(arr) - 1, mid_stack)
        
        if result != -1:
            print(f"Search for {key}: Found at index {result}")
        else:
            print(f"Search for {key}: Not found (-1)")
        
        if not mid_stack.is_empty():
            print(f"  Mid indices visited (stack): {mid_stack}")
    
    # Test case 2: Empty array
    empty_arr = []
    print(f"\nEmpty array: {empty_arr}")
    result = binary_search(empty_arr, 5, 0, len(empty_arr) - 1)
    print(f"Search for 5 in empty array: {result}")


def demonstrate_stack_adt():
    """Demonstrate Stack ADT operations."""
    print("\n" + "="*50)
    print("STACK ADT DEMONSTRATION")
    print("="*50)
    
    stack = StackADT()
    print(f"Stack created. Is empty? {stack.is_empty()}")
    
    # Push operations
    stack.push(10)
    stack.push(20)
    stack.push(30)
    print(f"After pushes (10,20,30): {stack}")
    print(f"Size: {stack.size()}")
    print(f"Peek: {stack.peek()}")
    
    # Pop operations
    print(f"Pop: {stack.pop()}")
    print(f"After pop: {stack}")
    print(f"Pop: {stack.pop()}")
    print(f"After pop: {stack}")
    print(f"Is empty? {stack.is_empty()}")


def main():
    """Main function to run all tests."""
    print("ALGORITHMIC EFFICIENCY & RECURSION TOOLKIT (AERT)")
    print("="*60)
    
    demonstrate_stack_adt()
    
    test_factorial()
    test_fibonacci()
    test_hanoi()
    test_binary_search()
    
    print("\n" + "="*50)
    print("ALL TESTS COMPLETED")
    print("="*50)


if __name__ == "__main__":
    main()